# PR: Add p402.io to llms-txt-hub

## Website

- **Name:** P402.io
- **URL:** https://p402.io
- **llms.txt:** https://p402.io/llms.txt
- **llms-full.txt:** https://p402.io/llms-full.txt
- **Category:** AI / Developer Tools / Payments

## Description

P402 is a payment-aware AI orchestration layer that routes LLM requests across 300+ models with cost optimization and settles micropayments in USDC on Base blockchain using the x402 protocol. The llms.txt provides a structured index of API documentation, Claude Skill downloads, key endpoints, and integration guides. The llms-full.txt provides the complete technical reference (1,985 lines) in a single file for deep context retrieval.

## Entry for README

```markdown
| [P402.io](https://p402.io/llms.txt) | AI orchestration with x402 payments | Developer Tools |
```
